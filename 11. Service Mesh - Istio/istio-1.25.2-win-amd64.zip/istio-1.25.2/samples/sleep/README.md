# sleep has been replaced

This sample has been replaced by the ["curl" sample](../curl/).
The new version is the same, except that the servie account, service, pod and container are now all called `curl` instead of `sleep`, to more accurately communicate the intended use in our documentation.

The original file is still provided, but please update any documentation or samples accordingly.
